import React from 'react';
import HRFormHandling from './LoginHRFormHandling.jsx';
import '../../App.css'

function HRLoginApp() {
	return (
		<div>
			<HRFormHandling />
		</div>
	);
}

export default HRLoginApp;
