import React from 'react';
import BasicFormHandling from './LoginEmployeeFormHandling.jsx';
import '../../App.css'

function App() {
 return (
 <div>

 <BasicFormHandling />
 </div>
 );
}
export default App;